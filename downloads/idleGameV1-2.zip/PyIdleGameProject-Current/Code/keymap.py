scSave = 'Shift+S' # Saves on press
scExit = 'Shift+Q' # Exits (and saves) on press

scMainTab = '1'
scUpgradeTab = '2'
scSettingsTab = '3'

