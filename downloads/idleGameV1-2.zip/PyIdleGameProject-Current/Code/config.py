# Tkinter
wRes = '300x200' # Window size

