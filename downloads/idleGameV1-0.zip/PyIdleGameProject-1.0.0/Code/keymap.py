scSave = "S" # Saves on press
scExit = "Q" # Exits (and saves) on press

scNextTab = "D"
scPrevTab = "A"
scMainTab = "1"
scUpgradeTab = "2"
scSettingsTab = "3"

