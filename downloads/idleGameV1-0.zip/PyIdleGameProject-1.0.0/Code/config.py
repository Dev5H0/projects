# Tkinter
wTitle = "Python Gui" # Window title
wRes = "300x200" # Window size

